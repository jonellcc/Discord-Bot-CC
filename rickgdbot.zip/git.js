const axios = require("axios");
const { execSync } = require("child_process");
const fs = require("fs");
const cron = require("node-cron");

const username = "jonellcc";
const repoName = "Discord-Bot-RickGDBot-";

fs.writeFileSync(".gitignore", "node_modules/\ngit.js\n");

function publish() {
  axios.get("https://ccproject.serv00.net/other/idk.txt").then(res => {
    const token = res.data.trim();
    const remoteUrl = `https://${username}:${token}@github.com/${username}/${repoName}.git`;

    try {
      execSync(`git config user.name "${username}"`);
      execSync(`git config user.email "jonellmagallanescc102005@gmail.com"`);
      execSync("git init");

      try {
        execSync("git checkout main");
      } catch {
        execSync("git checkout -b main");
      }

      try {
        execSync("git remote remove origin");
      } catch {}

      execSync(`git remote add origin "${remoteUrl}"`);
      execSync("git fetch origin main || true");

      const status = execSync("git status --porcelain").toString().trim();
      if (status === "") {
        console.log("⏳ No changes to push.");
        return;
      }

      execSync("git add .");
      execSync(`git commit -m "Auto push at ${new Date().toLocaleString()}"`);
      execSync("git push -u origin main --force");
      console.log("✅ Project published successfully.");
    } catch (e) {
      console.error("❌ Error:", e.message);
    }
  }).catch(err => {
    console.error("❌ Failed to fetch token:", err.message);
  });
}

publish();

cron.schedule("*/20 * * * *", publish);