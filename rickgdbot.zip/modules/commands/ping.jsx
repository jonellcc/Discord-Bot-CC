const axios = require('axios');
const { EmbedBuilder } = require("discord.js");

const tikTokRegex = /^(https?:\/\/)?(vt.tiktok.com|vm.tiktok.com|www.tiktok.com)/;
const capCutRegex = /^https:\/\/www.capcut.com\//;
const spotifyRegex = /^https:\/\/open.spotify.com\/track\//;
const soundCloudRegex = /^(https?:\/\/)?(m.soundcloud.com|soundcloud.com|on.soundcloud.com)/;
const newgroundsRegex = /^(https?:\/\/)?(www.newgrounds.com\/audio\/listen\/\d+)/;
const googleDriveRegex = /^(https?:\/\/)?(drive.google.com\/file\/d\/[a-zA-Z0-9_-]+\/?)/;
const dropboxRegex = /^https:\/\/www.dropbox.com\/scl\/fi\/[a-zA-Z0-9_-]+\/.+?rlkey=[a-zA-Z0-9]+&dl=0$/;

module.exports = {
    config: {
        name: 'uploadsong',
        description: 'Reupload music from TikTok, YouTube, CapCut, Spotify, SoundCloud, Newgrounds, or Google Drive',
        aliases: ["reupload", "upload"],
        usePrefix: false,
        permission: 0
    },
    run: async ({ discord: { client, message, args } }) => {
let link = args[0];

if (!link && message.reference) {
    if (!link) {
        return message.reply("Invalid link to reupload music. Please provide a valid link.");
    }
            const messageId = message.reference.messageId;
            const repliedMessage = await message.channel.messages.fetch(messageId);

            if (repliedMessage.attachments.size > 0) {
                const attachment = repliedMessage.attachments.first();
                const cdnLink = attachment.url;

                if (!cdnLink) {
                    return message.reply("Invalid media attachment.");
                }

                await processLink(cdnLink, message, true);
            } else {
                return message.reply("No attachment found in the replied message.");
            }
        } else {
            if (!link) {
                return message.reply("Invalid link to reupload music. Please provide a valid link.");
            }

            if (tikTokRegex.test(link) && link.includes('vm.tiktok.com')) {
                link = link.replace('vm.tiktok.com', 'vt.tiktok.com');
            }

            await processLink(link, message, false);
        }
    }
};

async function processLink(link, message, isCdn) {
    const initialEmbed = new EmbedBuilder()
        .setColor('#3498DB')
        .setDescription('🔄 Reuploading the song. Please wait...')
        .setThumbnail('https://files.catbox.moe/7fy4uv.gif')
        .setFooter({ text: `Requesting reupload song by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

    const sentMessage = await message.channel.send({ embeds: [initialEmbed] });

    async function updateProgress(percentage) {
        const progressEmbed = new EmbedBuilder()
            .setColor('#3498DB')
            .setDescription(`🔄 Reuploading the Song. Please wait...\nReuploading process at ${percentage}%`)
            .setThumbnail('https://files.catbox.moe/7fy4uv.gif')
            .setFooter({ text: `Requesting reupload song by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
        await sentMessage.edit({ embeds: [progressEmbed] });
    }

    try {
        let percentage = 1;
        await updateProgress(percentage);

        let apiUrl;

        if (newgroundsRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/ng?url=${link}`;
        } else if (googleDriveRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/gd?url=${link}`;
        } else if (isCdn) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/cdn?url=${link}`;
        } else if (soundCloudRegex.test(link) && link.includes('on.soundcloud.com')) {
            const response = await axios.get(`https://jonellpogi.serv00.net/converturl.php?url=${encodeURIComponent(link)}`);
            percentage += 20;
            await updateProgress(percentage);
            if (response.data && response.data.direct_link) {
                link = response.data.direct_link;
                apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/sc?url=${link}`;
            } else {
                throw new Error('Failed to convert SoundCloud link.');
            }
        } else if (tikTokRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/download?url=${link}`;
        } else if (capCutRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/cc?url=${link}`;
        } else if (dropboxRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/dropbox?url=${link}`;
        } else if (spotifyRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/spt?url=${link}`;
        } else {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/jonell?url=${link}`;
        }

        percentage += 20;
        await updateProgress(percentage);

        const response1 = await axios.get(apiUrl);
        const downloadUrl = response1.data.finalUrl;
        const filTit = response1.data.filTit;

        percentage += 30;
        await updateProgress(percentage);

        const headers = { 'User-Agent': 'Mozilla/5.1' };
        const response7 = await axios.get(
            `https://www.rickgdps.xyz/datastore/dashboard/api/addSong.php?download=${downloadUrl}&author=RickGDMusic&name=${filTit}`,
            { headers }
        );

        percentage += 20;
        await updateProgress(percentage);

        if (response7.data.dashboard && response7.data.success) {
            const songID = response7.data.song.ID;
            const songName = response7.data.song.name;

            const dbResponse = await axios.get(`https://jonellpogi.serv00.net/reupload.php?id=${songID}&title=${songName}&link=${link}`);

            if (dbResponse.data.status === "success") {
                percentage = 100;
                await updateProgress(percentage);

                const successEmbed = new EmbedBuilder()
                    .setColor('#2ECC71')
                    .setTitle('RickGDBot Reupload Song')
                    .setDescription(`<:successfully:1333466428174499860> **Successfully Reuploaded Song**\n\n<:song:1333468681627238470> **Song ID:** \`${songID}\`\n<:sound:1333470026614706239> **Song Name:** \`${songName}\`\n<:web:1333468807859273738> **URL:** ${link}`)
                    .setFooter({ text: `Reuploaded song by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

                await sentMessage.edit({ embeds: [successEmbed] });
            }
        }
    } catch (error) {
        const failedEmbed = new EmbedBuilder()
            .setColor('#E74C3C')
            .setTitle('<:query:1333468568213520494> RickGDBot Reuploading error')
            .setDescription(`❌ | Your song reupload failed. Try another URL or check for copyright issues.`)
            .setThumbnail('https://files.catbox.moe/4l19p0.png')
            .setFooter({ text: `Contact the developer Harold Hutchin`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

        await sentMessage.edit({ embeds: [failedEmbed] });
    }
}