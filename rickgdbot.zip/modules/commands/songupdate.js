const axios = require("axios");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  config: {
    name: "songupdate",
    description: "Change the music to Rickgdps for a specific song ID.",
    aliases: ["updatesong", "rickmusic"],
    usage: "/songupdate <id> | <downloadUrl>",
    cooldown: 10,
    usePrefix: true,
    permission: 0,
  },

  letStart: async ({ message, args }) => {
    const authorizedUsers = ["910196206414753792"];
    if (!authorizedUsers.includes(message.author.id)) {
      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle("Unauthorized")
        .setDescription("You are not authorized to use this command.")
        .setTimestamp()
        .setFooter({ text: "RickGDPS Song Update" });
      return message.reply({ embeds: [embed] });
    }

    if (!args[0] || !args.join(" ").includes("|")) {
      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle("Invalid Command Usage")
        .setDescription("Usage: /songupdate <id> | <downloadUrl>")
        .setTimestamp()
        .setFooter({ text: "RickGDPS Song Update" });
      return message.reply({ embeds: [embed] });
    }

    const [idRaw, downloadRaw] = args.join(" ").split("|").map(i => i.trim());
    const id = encodeURIComponent(idRaw);
    const download = encodeURIComponent(downloadRaw);

    const updatingMessage = await message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xffa500)
          .setTitle("Updating...")
          .setDescription("Please wait while the song is being updated.")
          .setTimestamp()
          .setFooter({ text: "RickGDPS Song Update" })
      ]
    });

    try {
      const headers = {
        "User-Agent": "Mozilla/5.0"
      };

      const songInfoRes = await axios.get(`https://www.rickgdps.xyz/datastore/dashboard/api/songs.php?search=${id}`, { headers });
      const name = encodeURIComponent(songInfoRes.data.song.name);

      const apiUrl = `https://www.rickgdps.xyz/datastore/dashboard/api/replaceSong.php?action=update&apikey=rickgdpscc&songID=${id}&name=${name}&author=RickGDMusic&downloadLink=${download}`;
      const updateRes = await axios.get(apiUrl, { headers });
      const response = updateRes.data;

      let embed;

      if (response.success && response.message === "Song updated successfully") {
        embed = new EmbedBuilder()
          .setColor(0x00ff00)
          .setTitle("<:successfully:1333466428174499860> Successfully Updated the Song")
          .setDescription(`The song has been updated to **${decodeURIComponent(name)}**.`)
          .addFields(
            { name: "<:song:1333468681627238470> Song Name", value: decodeURIComponent(name), inline: false },
            { name: "<:sound:1333470026614706239> ID", value: idRaw, inline: true },
            { name: "<:web:1333468807859273738> Song URL", value: decodeURIComponent(download), inline: false }
          )
          .setTimestamp()
          .setFooter({ text: "RickGDPS Song Update" });
      } else if (!response.success && response.error === 5) {
        embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setTitle("No Changes Made")
          .setDescription("No changes were made or invalid input.")
          .setTimestamp()
          .setFooter({ text: "RickGDPS Song Update" });
      } else {
        embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setTitle("Error")
          .setDescription(`Failed to update song: ${response.message || "Unknown error"}`)
          .setTimestamp()
          .setFooter({ text: "RickGDPS Song Update" });
      }

      await updatingMessage.edit({ content: "", embeds: [embed] });
    } catch (err) {
      const errorEmbed = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle("Error")
        .setDescription(`An error occurred: ${err.message}`)
        .setTimestamp()
        .setFooter({ text: "RickGDPS Song Update" });

      await updatingMessage.edit({ content: "", embeds: [errorEmbed] });
    }
  },
};