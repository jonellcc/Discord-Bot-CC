const axios = require('axios');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const stringSimilarity = require('string-similarity');

module.exports = {
		config: {
				name: 'searchsong',
				description: 'Search for a song in the uploaded list or show the latest 10 songs if no query is provided.',
				aliases: ['songsearch', 'findsong'],
				usage: '/searchsongname <query>',
				cooldown: 5,
				permission: 0,
				usePrefix: false,
		},

		letStart: async ({ message, args }) => {
				const query = args.join(' ').toLowerCase();

				try {
						const response = await axios.get('https://www.rickgdbot.xyz/admin/reupload.php?all');
						const songs = response.data;

						if (!Array.isArray(songs)) throw new Error("Invalid API response: Expected an array.");

						let results = [];

						if (!query) {
								results = songs.slice(0, 10);
						} else {
								results = songs.filter(song =>
										song.title.toLowerCase().includes(query) || song.id.toString() === query
								);
						}

						if (results.length === 0) {
								const titles = songs.map(song => song.title.toLowerCase());
								const matches = stringSimilarity.findBestMatch(query, titles);

								if (matches.bestMatch.rating >= 0.5) {
										const bestMatch = songs[matches.bestMatchIndex];

										const matchEmbed = new EmbedBuilder()
												.setColor('#F1C40F')
												.setTitle('No Exact Match Found — Showing Closest Match')
												.setDescription(
														`**Title:** ${bestMatch.title}\n` +
														`**Song ID:** \`${bestMatch.id}\`\n` +
														`**Link:** [Click here](${bestMatch.link})\n` +
														`**Uploaded:** ${bestMatch.created_at}\n\n` +
														`Closest match based on your search: **"${matches.bestMatch.target}"**`
												);

										return message.reply({ embeds: [matchEmbed] });
								} else {
										const noResultsEmbed = new EmbedBuilder()
												.setColor('#E74C3C')
												.setTitle('No Results Found')
												.setDescription(`No songs found matching **"${query}"**.`);
										return message.reply({ embeds: [noResultsEmbed] });
								}
						}

						let page = 0;
						const pageSize = 10;

						const getPage = (page) => {
								const start = page * pageSize;
								const end = start + pageSize;
								return results.slice(start, end);
						};

						const generateEmbed = (page) => {
								const paginatedResults = getPage(page);

								const embed = new EmbedBuilder()
										.setColor('#3498DB')
										.setTitle(query ? `Search Results for "${query}"` : 'Latest Uploaded Songs')
										.setDescription(paginatedResults.map(song =>
												`**Title:** ${song.title}\n` +
												`**Song ID:** \`${song.id}\`\n` +
												`**Link:** [Click here](${song.link})\n` +
												`**Uploaded:** ${song.created_at}`
										).join('\n\n'))
										.setFooter({ text: `Page ${page + 1} of ${Math.ceil(results.length / pageSize)}` });

								return embed;
						};

						const row = new ActionRowBuilder().addComponents(
								new ButtonBuilder()
										.setCustomId('prev')
										.setLabel('⬅️ Previous')
										.setStyle(ButtonStyle.Primary)
										.setDisabled(page === 0),
								new ButtonBuilder()
										.setCustomId('next')
										.setLabel('Next ➡️')
										.setStyle(ButtonStyle.Primary)
										.setDisabled(results.length <= pageSize)
						);

						const sentMessage = await message.reply({ embeds: [generateEmbed(page)], components: [row] });

						const collector = sentMessage.createMessageComponentCollector({ time: 60000 });

						collector.on('collect', async (interaction) => {
								if (interaction.user.id !== message.author.id) {
										return interaction.reply({ content: 'You can’t control this navigation!', ephemeral: true });
								}

								if (interaction.customId === 'prev' && page > 0) page--;
								if (interaction.customId === 'next' && (page + 1) * pageSize < results.length) page++;

								await interaction.update({ embeds: [generateEmbed(page)], components: [row] });

								row.components[0].setDisabled(page === 0);
								row.components[1].setDisabled((page + 1) * pageSize >= results.length);
						});

						collector.on('end', () => {
								sentMessage.edit({ components: [] });
						});

				} catch (error) {
						console.error("Error fetching or processing song data:", error);

						const errorEmbed = new EmbedBuilder()
								.setColor('#E74C3C')
								.setTitle('Error: Unable to Fetch Data')
								.setDescription(`There was an error retrieving the song list. Please try again later.`);
						return message.reply({ embeds: [errorEmbed] });
				}
		},
};