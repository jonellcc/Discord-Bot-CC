const os = require('os');
const { EmbedBuilder } = require("discord.js");

const allowedUsers = ['910196206414753792']; 

module.exports = {
	config: {
		name: 'uptime',
		description: 'Displays the bot uptime, system info, and ping.',
		aliases: ['up'],
		usage: '/uptime',
		cooldown: 5,
	usePrefix: false,
	permission: 0,

},

	letStart:	async function ({ message}) {
				if (!allowedUsers.includes(message.author.id)) {
						return message.reply("❌ You have no permission to use this command.");
				}

				const botUptime = process.uptime();
				const osUptime = os.uptime();
				const start = Date.now();

				const botHours = Math.floor(botUptime / 3600);
				const botMinutes = Math.floor((botUptime % 3600) / 60);
				const botSeconds = Math.floor(botUptime % 60);

				const osHours = Math.floor(osUptime / 3600);
				const osMinutes = Math.floor((osUptime % 3600) / 60);
				const osSeconds = Math.floor(osUptime % 60);

				const osPlatform = `${os.type()} ${os.release()}`;

				const embed = new EmbedBuilder()
						.setColor('#3498DB')
						.setTitle('Uptime Information')
						.setDescription('Details of the system uptime and bot performance:')
						.addFields(
								{ name: '🖥️ OS', value: osPlatform, inline: true },
								{ name: '⏳ Bot Uptime', value: `${botHours}h ${botMinutes}m ${botSeconds}s`, inline: true },
								{ name: '⏱️ OS Uptime', value: `${osHours}h ${osMinutes}m ${osSeconds}s`, inline: true },
								{ name: '⚡ Ping', value: 'Calculating...', inline: false }
						)
						.setThumbnail('https://files.catbox.moe/a7cwoc.png');

				const sentMessage = await message.reply({ embeds: [embed] });

				const ping = Date.now() - start;

				embed.spliceFields(3, 1, { name: '⚡ Ping', value: `${ping}ms`, inline: false });
				sentMessage.edit({ embeds: [embed] });
		},
};