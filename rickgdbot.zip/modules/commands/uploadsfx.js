const axios = require('axios');
const { EmbedBuilder } = require("discord.js");
const fs = require('fs');

let userCooldowns = {};
let dailyUsage = {};

try {
    userCooldowns = JSON.parse(fs.readFileSync('./modules/commands/data/sfxCooldowns.json'));
} catch (err) {
    fs.writeFileSync('./modules/commands/data/sfxCooldowns.json', JSON.stringify({}));
}

try {
    dailyUsage = JSON.parse(fs.readFileSync('./modules/commands/data/sfxDailyUsage.json'));
} catch (err) {
    fs.writeFileSync('./modules/commands/data/sfxDailyUsage.json', JSON.stringify({}));
}

function saveCooldowns() {
    fs.writeFileSync('./modules/commands/data/sfxCooldowns.json', JSON.stringify(userCooldowns));
}

function saveDailyUsage() {
    fs.writeFileSync('./modules/commands/data/sfxDailyUsage.json', JSON.stringify(dailyUsage));
}

function formatTime(ms) {
    if (ms > 3600000) return `${Math.floor(ms / 3600000)} hours`;
    if (ms > 60000) return `${Math.floor(ms / 60000)} minutes`;
    return `${Math.floor(ms / 1000)} seconds`;
}

async function checkExistingSFX(name, link) {
    try {
        const response = await axios.get('https://www.rickgdbot.xyz/admin/sfx.php?all');
        const sfxList = response.data;
        
        for (const sfx of sfxList) {
            if (name && sfx.name.toLowerCase() === name.toLowerCase()) {
                return { exists: true, sfx };
            }
            if (link && sfx.link === link) {
                return { exists: true, sfx };
            }
        }
        
        return { exists: false };
    } catch (error) {
        console.error('Error checking existing SFX:', error);
        return { exists: false };
    }
}

module.exports = {
    config: {
        name: 'uploadsfx',
        description: 'Upload SFX (Sound Effect) via URL',
        aliases: ['upload-sfx', 'sfxupload'],
        usage: '/uploadsfx <url> - <name (optional for YouTube)>',
        cooldown: 10,
        permission: 0,
        usePrefix: false,
    },
    letStart: async({ message, args }) => {
        const userId = message.author.id;
        const currentTime = Date.now();
        const now = new Date();
        
        if (userCooldowns[userId] && currentTime < userCooldowns[userId].cooldownEnd) {
            const remainingTime = userCooldowns[userId].cooldownEnd - currentTime;
            const cooldownEmbed = new EmbedBuilder()
                .setColor('#E74C3C')
                .setTitle('Command Cooldown')
                .setDescription(`<:timehshs:1364186671658172466> <@${userId}> **uploadsfx** command has been cooldown\nPlease comeback at ${formatTime(remainingTime)} to reuse again thank you!`)
                .setThumbnail('https://files.catbox.moe/zjvkxy.png');
            return message.reply({ embeds: [cooldownEmbed] });
        }

        const today = now.toDateString();
        if (!dailyUsage[userId]) {
            dailyUsage[userId] = { date: today, count: 1 };
        } else {
            if (dailyUsage[userId].date !== today) {
                dailyUsage[userId] = { date: today, count: 1 };
            } else if (dailyUsage[userId].count >= 5) {
                const midnight = new Date();
                midnight.setHours(24, 0, 0, 0);
                const remainingTime = midnight - now;
                
                const limitEmbed = new EmbedBuilder()
                    .setColor('#E74C3C')
                    .setTitle('Daily Limit Reached')
                    .setDescription(`<:timehshs:1364186671658172466> <@${userId}> you have reached your daily limit of 5 uses for the **uploadsfx** command. Please try again tomorrow.\n\nWaiting time: ${formatTime(remainingTime)}`)
                    .setThumbnail('https://files.catbox.moe/zjvkxy.png');
                return message.reply({ embeds: [limitEmbed] });
            } else {
                dailyUsage[userId].count += 1;
            }
        }

        if (!args.length) {
            const embed = new EmbedBuilder()
                .setColor('#E74C3C')
                .setTitle('Error: Missing Arguments')
                .setDescription('Please provide the URL (mp3 or YouTube link) and optionally the name of the SFX.\n\nUsage: `/uploadsfx <url> - <name>`\n\nExamples:\n`/uploadsfx https://youtu.be/xyz`\n`/uploadsfx https://example.com/sfx-file.mp3 - Name of SFX`\n\nVisit this site \n[Catbox file Uploader](https://catbox.moe)\nto upload your file, then use the URL here as the argument.')
                .setThumbnail('https://files.catbox.moe/zjvkxy.png');
            return message.reply({ embeds: [embed] });
        }

        const input = args.join(' ').split(' - ');
        const url = input[0].trim();
        const name = input[1]?.trim();

        if (!url) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#E74C3C')
                .setTitle('Error: Invalid URL')
                .setDescription('Please provide a valid URL for the SFX upload.')
                .setThumbnail('https://files.catbox.moe/zjvkxy.png');
            return message.reply({ embeds: [errorEmbed] });
        }

        if (!name && !(url.includes('youtube.com') || url.includes('youtu.be'))) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#E74C3C')
                .setTitle('Error: Missing SFX Name')
                .setDescription('For direct MP3 links, providing a name is required.\n\nUsage: `/uploadsfx <mp3_url> - <name>`')
                .setThumbnail('https://files.catbox.moe/zjvkxy.png');
            return message.reply({ embeds: [errorEmbed] });
        }

        const username = message.author.username;
        const initialEmbed = new EmbedBuilder()
            .setColor('#3498DB')
            .setDescription('Checking database...')
            .setThumbnail('https://files.catbox.moe/igl3bn.gif');
        const sentMessage = await message.channel.send({ embeds: [initialEmbed] });

        async function updateProgress(percentage, status) {
            const progressEmbed = new EmbedBuilder()
                .setColor('#3498DB')
                .setDescription(`<a:request:1354831260211482735> ${status}\nUploading process at ${percentage}%`)
                .setThumbnail('https://files.catbox.moe/igl3bn.gif');
            await sentMessage.edit({ embeds: [progressEmbed] });
        }

        try {
            await updateProgress(10, 'Checking database...');

            const existingSFX = await checkExistingSFX(name, url);
            if (existingSFX.exists) {
                const existsEmbed = new EmbedBuilder()
                    .setColor('#E74C3C')
                    .setTitle('SFX Reupload Rejected')
                    .setDescription(`This SFX has been rejected to reupload because its already Reuploaded at name of SFX \`${existingSFX.sfx.name}\` at Folder SFX in \`${existingSFX.sfx.author}\``)
                    .setThumbnail('https://files.catbox.moe/5kt78l.png');
                return sentMessage.edit({ embeds: [existsEmbed] });
            }

            await updateProgress(20, 'Starting upload process...');

            let apiUrl;
            if (url.includes('youtube.com') || url.includes('youtu.be')) {
                apiUrl = name
                    ? `https://jonellpogi.serv00.net/sfxupload.php?yt=${encodeURIComponent(url)}&name=${encodeURIComponent(name)}`
                    : `https://jonellpogi.serv00.net/sfxupload.php?yt=${encodeURIComponent(url)}`;
            } else {
                apiUrl = `https://jonellpogi.serv00.net/sfx.php?url=${encodeURIComponent(url)}&name=${encodeURIComponent(name)}`;
            }

            await updateProgress(40, 'Processing SFX...');
            const response = await axios.get(apiUrl);

            if (response.data.error === 'File size exceeds 1MB limit.') {
                const errorEmbed = new EmbedBuilder()
                    .setColor('#E74C3C')
                    .setTitle('Error Uploading SFX')
                    .setDescription('This YouTube link cannot upload as an SFX because the 1MB limit has been reached.')
                    .setThumbnail('https://files.catbox.moe/zjvkxy.png');
                return sentMessage.edit({ embeds: [errorEmbed] });
            }

            await updateProgress(60, 'Uploading to server...');
            const { message: apiMessage, data } = response.data;

            if (apiMessage === 'SFX added successfully.') {
                const databaseResponse = await axios.get(
                    `https://www.rickgdbot.xyz/admin/sfx.php?name=${encodeURIComponent(data.name)}&size=${encodeURIComponent(data.size)}&link=${encodeURIComponent(data.link)}&author=${encodeURIComponent(data.author)}&rt=${encodeURIComponent(data.reupload_time)}`
                );

                if (databaseResponse.data.status === "error" && databaseResponse.data.message === "This name or link is already uploaded in the database") {
                    const existsEmbed = new EmbedBuilder()
                        .setColor('#E74C3C')
                        .setTitle('SFX Reupload Rejected')
                        .setDescription(`<:unsucess:1333466610156961962> This SFX has been rejected to reupload because its already Reuploaded at name of SFX \`${data.name}\``)
                        .setThumbnail('https://files.catbox.moe/5kt78l.png');
                    return sentMessage.edit({ embeds: [existsEmbed] });
                }

                if (databaseResponse.data.status === "success" && databaseResponse.data.message === "Successfully Added list") {
                    await updateProgress(100, 'Completed!');
                    const successEmbed = new EmbedBuilder()
                        .setColor('#2ECC71')
                        .setTitle('<:successfully:1333466428174499860> SFX Uploaded Successfully')
                        .setDescription(`👤 Uploaded Custom SFX By  **${username}**\n\n<:sfx:1333483217264840808> SFX Name: **${data.name}**\n<:profile:1333486106578260082> SFX Author: **${data.author}**\n<:folder:1333485662149545994> Size: **${data.size}**`)
                        .addFields(
                            { name: '<:dl:1333482602320892045> Download Link', value: `[Click Here](${data.link})`, inline: false },
                            { name: '<:time:1333483136100864032> Reupload Time', value: data.reupload_time, inline: true },
                            { name: '<:web:1333468807859273738> SFX Library', value: '[RickGDBot Library SFX](https://www.rickgdbot.xyz/library/)', inline: false }
                        );
                    await sentMessage.edit({ embeds: [successEmbed] });
                } else {
                    throw new Error('Failed to add SFX to the database');
                }
            } else {
                throw new Error('Failed to add SFX');
            }
        } catch (error) {
            console.error("SFX upload error:", error);
            const errorEmbed = new EmbedBuilder()
                .setColor('#E74C3C')
                .setTitle('Reupload SFX Error')
                .setDescription(`<:unsucess:1333466610156961962> | Sorry your reupload SFX was not successful. Try another link or check the server of RGDPS`);

            await sentMessage.edit({ embeds: [errorEmbed] });
        } finally {
            userCooldowns[userId] = { cooldownEnd: currentTime + 10000 };
            saveCooldowns();
            saveDailyUsage();
        }
    },
};