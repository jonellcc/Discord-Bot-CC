const { EmbedBuilder } = require("discord.js");
const os = require("os");

module.exports = {
	config: {
		name: "about",
		description: "Displays real-time information about RickGDBot.",
		aliases: ["botinfo", "info"],
		usage: "",
		cooldown: 30,
   permission: 0,
	usePrefix: false,
	},	
		letStart: async function ({ message}) {
				const totalRAM = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
				const freeRAM = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);
				const usedRAM = (totalRAM - freeRAM).toFixed(2);
				const uptime = os.uptime();
				const osType = os.type();
				const osArch = os.arch();

				const ping = Date.now() - message.createdTimestamp;

				const embed = new EmbedBuilder()
						.setTitle("About RickGDBot")
						.setDescription(
								"**RickGDBot** is a Bot Assistant Alternative similar to ObeyGDBot by Migmatos. " +
								"However, RickGDBot offers more features such as:\n\n" +
								"**Support for links:** YouTube, TikTok, Spotify, CapCut Template Links, SoundCloud, Newgrounds and Google drive link\n\n" +
								"• File attachment upload and re-upload SFX to your levels\n" +
								"• And much more!!"
						)
						.addFields(
								{ name: "**Bot Programming Language:**", value: "Node.js & PHP", inline: false },
								{ name: "**Database:**", value: "RickGDBot uses **MySQL** and **JSON** for data storage.", inline: false },
								{ name: "**OS:**", value: `${osType} (${osArch})`, inline: false },
								{ name: "**RAM:**", value: `Total: ${totalRAM} GB\n• Used: ${usedRAM} GB\n• Available: ${freeRAM} GB`, inline: false },
								{ name: "**Uptime:**", value: `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m ${Math.floor(uptime % 60)}s`, inline: false },
								{ name: "**Ping Latency:**", value: `${ping} ms`, inline: false }, // Real-time ping
								{ name: "**Special Thanks:**", value: "Big thanks to **Johnrick GD** for featuring the bot and helping to build it.\n\n" +
										"• Special thanks to **RGDPS Players** and **You** for supporting and using the bot!", inline: false },
								{ name: "**Developers:**", value: "Harold Hutchins and JohnrickGD", inline: false },
								{ name: "**Powered by:**", value: "Rick GDPS", inline: false }
						)
						.setFooter({ text: "Thank you for using RickGDBot. Type r!help for more commands!" })
						.setColor("Random");

				message.channel.send({ embeds: [embed] });
		},
};