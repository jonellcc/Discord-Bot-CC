const axios = require('axios');
const { EmbedBuilder } = require("discord.js");

module.exports = {
	config: {
		name: 'status',
		description: 'Monitor RGDPS servers in real-time.',
		aliases: ['serverstatus', 'monitor'],
		usage: '/status',
		cooldown: 10,
 usePrefix: true,
		permission: 0,
	},
		letStart: async ({message}) => {
				const servers = [
						{ name: 'Main Server', url: 'https://www.rickgdps.xyz' },
						{ name: 'Server Dashboard', url: 'https://www.rickgdps.xyz/datastore/dashboard/' },
				];

				const statuses = [];
				for (const server of servers) {
						try {
								const response = await axios.get(server.url);
								statuses.push({ name: server.name, status: response.status === 200 ? 'green' : 'orange' });
						} catch {
								statuses.push({ name: server.name, status: 'red' });
						}
				}

				const statusColors = statuses.some(s => s.status === 'red') 
						? '#E74C3C' 
						: statuses.every(s => s.status === 'green') 
						? '#2ECC71' 
						: '#F1C40F';

				const statusDescription = statuses
						.map(s => `**${s.name}**: ${s.status === 'green' ? '🟢 Online' : s.status === 'orange' ? '🟠 Issues' : '🔴 Down'}`)
						.join('\n');

				const embed = new EmbedBuilder()
						.setColor(statusColors)
						.setTitle('RGDPS Status Server')
						.setDescription(statusDescription)
						.setTimestamp();

				message.reply({ embeds: [embed] });
		},
};