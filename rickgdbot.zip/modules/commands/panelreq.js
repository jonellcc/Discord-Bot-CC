const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const axios = require('axios');

const roleAuth = ['1332565170123444235', '1067281899522900028', '1067281412551606324', '1067280979917549639', '1060064761540255824'];

module.exports = {
    config: {
        name: 'pr',
        description: 'Review a level request or view pending levels.',
        usage: '!review <levelID> <accept/decline> <reason> OR !review levels',
        permissions: ['ManageGuild']
    },

    async letStart({ args, message }) {
        const processingEmbed = new EmbedBuilder()
            .setColor(0xFFFF00)
            .setDescription('<:timehshs:1364186671658172466> Processing Data...');

        const processingMsg = await message.reply({ embeds: [processingEmbed] });

        const memberRoles = message.member.roles.cache.map(role => role.id);
        if (!roleAuth.some(role => memberRoles.includes(role))) {
            const errorEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setDescription('<:unsucess:1333466610156961962> You do not have permission to use this command.');
            return processingMsg.edit({ embeds: [errorEmbed] });
        }

        if (args.length === 1 && args[0].toLowerCase() === 'levels') {
            try {
                const { data: levelData } = await axios.get('https://www.rickgdbot.xyz/admin/reqlist.json');

                if (!levelData || levelData.length === 0) {
                    const noLevelsEmbed = new EmbedBuilder()
                        .setColor(0x00FF00)
                        .setDescription('<:timehshs:1364186671658172466> There are no pending level requests at the moment.');
                    return processingMsg.edit({ embeds: [noLevelsEmbed] });
                }

                const itemsPerPage = 5;
                let currentPage = 0;

                const generateEmbed = (page, data) => {
                    const start = page * itemsPerPage;
                    const end = start + itemsPerPage;
                    const paginatedLevels = data.slice(start, end);

                    const embed = new EmbedBuilder()
                        .setColor(0x0099FF)
                        .setTitle('<:timehshs:1364186671658172466> Pending Level Requests')
                        .setDescription('Here are the levels awaiting review:')
                        .setFooter({ text: `Page ${page + 1} of ${Math.ceil(data.length / itemsPerPage)}` });

                    paginatedLevels.forEach(level => {
                        embed.addFields(
                            { name: `Level Name:`, value: `${level.levelName}`, inline: true },
                            { name: `Level ID:`, value: `${level.levelId}`, inline: true },
                            { name: `Requester:`, value: `${level.requester}`, inline: true },
                            { name: `Submission Date:`, value: `${level.date}`, inline: true },
                            { name: `Description:`, value: `${level.description || 'N/A'}`, inline: false },
                            { name: `---`, value: `\u200B`, inline: false }
                        );
                    });
                    return embed;
                };

                const generateButtons = (page, data) => {
                    return new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId('previous_level_page')
                                .setLabel('⬅️ Previous')
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(page === 0),
                            new ButtonBuilder()
                                .setCustomId('next_level_page')
                                .setLabel('Next ➡️')
                                .setStyle(ButtonStyle.Primary)
                                .setDisabled(page === Math.ceil(data.length / itemsPerPage) - 1),
                        );
                };

                await processingMsg.edit({
                    embeds: [generateEmbed(currentPage, levelData)],
                    components: [generateButtons(currentPage, levelData)]
                });

                const collector = processingMsg.createMessageComponentCollector({
                    filter: i => i.user.id === message.author.id,
                    time: 60000 * 5
                });

                collector.on('collect', async i => {
                    if (i.customId === 'next_level_page') {
                        currentPage++;
                    } else if (i.customId === 'previous_level_page') {
                        currentPage--;
                    }

                    await i.update({
                        embeds: [generateEmbed(currentPage, levelData)],
                        components: [generateButtons(currentPage, levelData)]
                    });
                });

                collector.on('end', async () => {
                    await processingMsg.edit({ components: [] });
                });

            } catch (error) {
                console.error('Error fetching level requests:', error);
                const errorEmbed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setDescription('An error occurred while fetching level requests. Please try again later.');
                processingMsg.edit({ embeds: [errorEmbed] });
            }
            return;
        }

        if (args.length < 3) {
            const usageEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setDescription('Usage: r! review <levelID> <accept/decline> <reason> OR !review levels');
            return processingMsg.edit({ embeds: [usageEmbed] });
        }

        const [levelid, action, ...reasonParts] = args;
        const reason = reasonParts.join(' ');
        const currentLogin = message.author.username;
        const reviewerAvatar = message.author.displayAvatarURL({ dynamic: true });
        const reviewDateTime = new Date().toLocaleString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });

        try {
            const { data: levelData } = await axios.get('https://www.rickgdbot.xyz//admin/reqlist.json');
            const level = levelData.find(lvl => lvl.levelId === levelid);

            if (!level) {
                const notFoundEmbed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setDescription(`<:timehshs:1364186671658172466> Level ID \`${levelid}\` not found in the request list.`);
                return processingMsg.edit({ embeds: [notFoundEmbed] });
            }

            const levelName = level.levelName;
            let resultEmbed;

            if (action.toLowerCase() === 'accept') {
                await axios.get(`https://www.rickgdbot.xyz/admin/notireq.php?username=${encodeURIComponent(currentLogin)}&levelname=${encodeURIComponent(levelName)}&levelid=${levelid}&reason=${encodeURIComponent(reason)}&serverid=1060035543372681217&channelid=1200950060372983828`);
                resultEmbed = new EmbedBuilder()
                    .setColor(0x00FF00)
                    .setTitle('<:successfully:1333466428174499860> Level had been Accepted')
                    .setDescription(`<:savelevel:1377937136132685894> **Level:** ${levelName}\n<:play10:1373645663488839700> **ID:** ${levelid}\n<:infolevel:1373653092758982687> **Reason:** ${reason}`)
                    .setFooter({ text: `Reviewed by ${currentLogin} at ${reviewDateTime}`, iconURL: reviewerAvatar });
            }
            else if (action.toLowerCase() === 'decline') {
                await axios.get(`https://www.rickgdbot.xyz/admin/reqdec.php?username=${encodeURIComponent(currentLogin)}&levelname=${encodeURIComponent(levelName)}&levelid=${levelid}&reason=${encodeURIComponent(reason)}&serverid=1060035543372681217&channelid=1200950060372983828`);
                resultEmbed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('<:successfully:1333466428174499860> Level has been Declined')
                    .setDescription(`<:savelevel:1377937136132685894> **Level:** ${levelName}\n<:play10:1373645663488839700> **ID:** ${levelid}\n<:infolevel:1373653092758982687> **Reason:** ${reason}`)
                    .setFooter({ text: `Reviewed by ${currentLogin} at ${reviewDateTime}`, iconURL: reviewerAvatar });
            }
            else {
                const invalidActionEmbed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setDescription('<:unsucess:1333466610156961962> Invalid action. Use "accept" or "decline".');
                return processingMsg.edit({ embeds: [invalidActionEmbed] });
            }

            await processingMsg.edit({ embeds: [resultEmbed] });
            await axios.get(`https://www.rickgdbot.xyz/admin/reqlist.php?id=${levelid}`);

        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setDescription('An error occurred while processing your request.');
            processingMsg.edit({ embeds: [errorEmbed] });
        }
    }
};