const axios = require('axios');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require("discord.js");
const fs = require('fs');

const tikTokRegex = /^(https?:\/\/)?(vt\.tiktok\.com|vm\.tiktok\.com|www\.tiktok\.com)/;
const capCutRegex = /^https:\/\/www\.capcut\.com\//;
const spotifyRegex = /^https:\/\/open\.spotify\.com\/track\//;
const soundcloudRegex = /^(?:https?:\/\/)?(?:[a-zA-Z0-9-]+\.)?soundcloud\.com\/[a-zA-Z0-9-.~!$&'()*+,;=:@%]+(?:\/[a-zA-Z0-9-.~!$&'()+,;=:@%]+)?\/?$/;
const newgroundsRegex = /^(https?:\/\/)?(www\.newgrounds\.com\/audio\/listen\/\d+)/;
const googleDriveRegex = /^(https?:\/\/)?(drive\.google\.com\/file\/d\/[a-zA-Z0-9_-]+\/?)/;
const dropboxRegex = /^https:\/\/www\.dropbox\.com\/scl\/fi\/[a-zA-Z0-9_-]+\/.+?rlkey=[a-zA-Z0-9]+&dl=0$/;
const youtubeRegex = /^(?:https?:\/\/)?(?:[a-zA-Z0-9-]+\.)?youtube\.com\/(?:.*[?&]v=|embed\/|v\/|shorts\/|live\/|playlist\?list=|watch\?v=)([a-zA-Z0-9_-]{11})|(?:https?:\/\/)?youtu\.be\/([a-zA-Z0-9_-]{11})(?:\S+)?$/;
const instagramRegex = /https?:\/\/(www\.)?instagram\.com\/reel\/[a-zA-Z0-9_-]+\/?/;
const exception = ["1261231423486951465"];

let userCooldowns = {};
let dailyUsage = {};

try {
  userCooldowns = JSON.parse(fs.readFileSync('./modules/commands/cooldowns.json'));
} catch (err) {
  fs.writeFileSync('./modules/commands/cooldowns.json', JSON.stringify({}));
}

try {
  dailyUsage = JSON.parse(fs.readFileSync('./dailyUsage.json'));
} catch (err) {
  fs.writeFileSync('./modules/commands/data/dailyUsage.json', JSON.stringify({}));
}

function saveCooldowns() {
  fs.writeFileSync('./modules/commands/cooldowns.json', JSON.stringify(userCooldowns));
}

function saveDailyUsage() {
  fs.writeFileSync('./modules/commands/dailyUsage.json', JSON.stringify(dailyUsage));
}

function formatTime(ms) {
  if (ms > 3600000) return `${Math.floor(ms / 3600000)} hours`;
  if (ms > 60000) return `${Math.floor(ms / 60000)} minutes`;
  return `${Math.floor(ms / 1000)} seconds`;
}

async function checkExistingSong(link, title) {
  try {
    const response = await axios.get('https://www.rickgdbot.xyz/admin/reupload.php?all');
    const songs = response.data;
    const youtubeId = link.match(youtubeRegex)?.[1] || link.match(youtubeRegex)?.[2];
    
    if (tikTokRegex.test(link)) {
      return { exists: false };
    }

    for (const song of songs) {
      const existingYoutubeId = song.link.match(youtubeRegex)?.[1] || song.link.match(youtubeRegex)?.[2];
      if (youtubeId && existingYoutubeId && youtubeId === existingYoutubeId) {
        return { exists: true, songID: song.id, songName: song.title };
      }
      if (title && song.title.toLowerCase() === title.toLowerCase()) {
        return { exists: true, songID: song.id, songName: song.title };
      }
    }
    return { exists: false };
  } catch (error) {
    return { exists: false };
  }
}

async function processLinkWithRetry(link, message, isCdn, attempt = 1) {
  try {
    const result = await processLink(link, message, isCdn);
    return result;
  } catch (error) {
    if (attempt >= 2) {
      throw error;
    }
    
    const retryEmbed = new EmbedBuilder()
      .setColor('#FFA500')
      .setDescription(`Reattempting in 3 seconds... (Attempt ${attempt + 1}/2)`)
      .setFooter({ text: `Requesting reupload song by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
    
    const sentMessage = await message.channel.send({ embeds: [retryEmbed] });
    await new Promise(resolve => setTimeout(resolve, 3000));
    await sentMessage.delete();
    return processLinkWithRetry(link, message, isCdn, attempt + 1);
  }
}

module.exports = {
  config: {
    name: 'uploadsong',
    description: 'Reupload music from TikTok, YouTube, CapCut, Spotify, SoundCloud, Newgrounds, or Google Drive',
    aliases: ["reupload", "upload"],
    usage: 'link',
    cooldown: 30,
    permission: 0,
    usePrefix: false,
  },
  letStart: async ({ args, message }) => {
    const userId = message.author.id;
    const currentTime = Date.now();
    const member = message.member;
    const now = new Date();
    const hasExceptionRole = exception.some(roleId => member.roles.cache.has(roleId));

    if (!hasExceptionRole && userCooldowns[userId] && currentTime < userCooldowns[userId].cooldownEnd) {
      const remainingTime = userCooldowns[userId].cooldownEnd - currentTime;
      const cooldownEmbed = new EmbedBuilder()
        .setColor('#E74C3C')
        .setTitle('<:timehshs:1364186671658172466> Command Cooldowns')
        .setDescription(`<@${userId}> **uploadsong** command has been cooldown\nPlease comeback at ${formatTime(remainingTime)} to reuse again thank you!`)
        .setFooter({ text: `Just wait for Cooldowns ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
      return message.reply({ embeds: [cooldownEmbed] });
    }

    const today = now.toDateString();
    let shouldCountUsage = true;
    let link = args && args.length > 0 ? args[0] : null;

    if (!link && message.reference) {
      const messageId = message.reference.messageId;
      const repliedMessage = await message.channel.messages.fetch(messageId);
      if (repliedMessage.attachments.size > 0) {
        const attachment = repliedMessage.attachments.first();
        link = attachment.url;
        if (!link) {
          shouldCountUsage = false;
          return message.reply("Invalid media attachment.");
        }
      } else {
        shouldCountUsage = false;
        return message.reply("No attachment found in the replied message.");
      }
    }

    if (!link) {
      shouldCountUsage = false;
      return message.reply("Invalid link to reupload music. Please provide a valid link.");
    }

    if (!tikTokRegex.test(link) && !capCutRegex.test(link) && !spotifyRegex.test(link) && !soundcloudRegex.test(link) && !newgroundsRegex.test(link) && !googleDriveRegex.test(link) && !dropboxRegex.test(link) && !youtubeRegex.test(link) && !instagramRegex.test(link)) {
      shouldCountUsage = false;
      const invalidLinkEmbed = new EmbedBuilder()
        .setColor('#E74C3C')
        .setTitle('<:query:1333468568213520494> Invalid Link Reupload Song')
        .setDescription('The provided link is not valid. Please provide a valid link from TikTok, YouTube, CapCut, Spotify, SoundCloud, Newgrounds, Google Drive, or Dropbox.')
        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
      return message.reply({ embeds: [invalidLinkEmbed] });
    }

    if (shouldCountUsage && !hasExceptionRole) {
      if (!dailyUsage[userId]) {
        dailyUsage[userId] = { date: today, count: 1 };
      } else {
        if (dailyUsage[userId].date !== today) {
          dailyUsage[userId] = { date: today, count: 1 };
        } else if (dailyUsage[userId].count >= 2) {
          const midnight = new Date();
          midnight.setHours(24, 0, 0, 0);
          const remainingTime = midnight - now;
          const limitEmbed = new EmbedBuilder()
            .setColor('#E74C3C')
            .setTitle('<:timehshs:1364186671658172466> Daily Limit Reached')
            .setDescription(`<@${userId}> you have reached your daily limit of 2 uses for the **uploadsong** command. Please try again tomorrow.\n\nWaiting time: ${formatTime(remainingTime)}`)
            .setFooter({ text: `Try to use again tomorrow ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
          return message.reply({ embeds: [limitEmbed] });
        } else {
          dailyUsage[userId].count += 1;
        }
      }
    }

    if (tikTokRegex.test(link) && link.includes('vm.tiktok.com')) {
      link = link.replace('vm.tiktok.com', 'vt.tiktok.com');
    }

    try {
      const result = await processLinkWithRetry(link, message, false);
      if (result !== 'exists' && !hasExceptionRole) {
        userCooldowns[userId] = { cooldownEnd: currentTime + 30000 };
        saveCooldowns();
        saveDailyUsage();
      }
    } catch (error) {
      const reason = error.response?.data?.error || error.message;
      const failedEmbed = new EmbedBuilder()
        .setColor('#E74C3C')
        .setTitle('RickGDBot Reuploading Failed')
        .setDescription(`<:unsucess:1333466610156961962> Failed to reupload after 2 attempts\n\nReason: ${reason}`)
        .setThumbnail('https://files.catbox.moe/4l19p0.png')
        .setFooter({ text: `Contact the developer this error Harold Hutchin`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
      await message.channel.send({ embeds: [failedEmbed] });
    }
  },
};

async function processLink(link, message, isCdn) {
  const initialEmbed = new EmbedBuilder()
    .setColor('#3498DB')
    .setDescription('<:timehshs:1364186671658172466> Checking database...')
    .setFooter({ text: `Requesting reupload song by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
  const sentMessage = await message.channel.send({ embeds: [initialEmbed] });

  async function updateProgress(percentage, status) {
    const progressEmbed = new EmbedBuilder()
      .setColor('#3498DB')
      .setDescription(`<a:dlgd:1368926386865180693> ${status}\nReuploading process at ${percentage}%`)
      .setFooter({ text: `Requesting reupload song by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
    await sentMessage.edit({ embeds: [progressEmbed] });
  }

  try {
    await updateProgress(10, 'Checking database...');
    const dbCheck = await checkExistingSong(link);
    if (dbCheck.exists) {
      const existsEmbed = new EmbedBuilder()
        .setColor('#E74C3C')
        .setTitle('<:nosound:1356948863922995312> Song Reupload Rejected!')
        .setDescription(`This song has been reuploaded already with:\n\nSong ID: \`${dbCheck.songID}\`\nSong Name: \`${dbCheck.songName}\``)
        .setFooter({ text: `This is Already Uploaded ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
      await sentMessage.edit({ embeds: [existsEmbed] });
      return 'exists';
    }

    await updateProgress(20, 'Starting reupload process...');
    let apiUrl;
    let filTit = '';
    let finalDownloadUrl = '';

    if (newgroundsRegex.test(link)) {
      apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/ng?url=${link}`;
    } else if (googleDriveRegex.test(link)) {
      apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/gd?url=${link}`;
    } else if (isCdn) {
      apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/cdn?url=${link}`;
    } else if (soundcloudRegex.test(link) && link.includes('on.soundcloud.com')) {
      const response = await axios.get(`https://jonellpogi.serv00.net/converturl.php?url=${encodeURIComponent(link)}`);
      await updateProgress(40, 'Converting SoundCloud link...');
      if (response.data && response.data.direct_link) {
        link = response.data.direct_link;
        apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/sc?url=${link}`;
      } else {
        throw new Error('Failed to convert SoundCloud link.');
      }
    } else if (tikTokRegex.test(link)) {
      apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/download?url=${link}`;
    } else if (capCutRegex.test(link)) {
      apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/cc?url=${link}`;
    } else if (dropboxRegex.test(link)) {
      apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/dropbox?url=${link}`;
    } else if (spotifyRegex.test(link)) {
      apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/spt?url=${link}`;
    } else if (youtubeRegex.test(link)) {
      apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/jonell?url=${link}`;
    } else if (instagramRegex.test(link)) {
      apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/instadl?url=${link}`;
    }

    await updateProgress(50, 'Downloading song...');
    const response1 = await axios.get(apiUrl);
    const downloadUrl = response1.data.finalUrl;
    filTit = response1.data.filTit;
    finalDownloadUrl = response1.data.finalUrl;

    const titleCheck = await checkExistingSong(link, filTit);
    if (titleCheck.exists) {
      const existsEmbed = new EmbedBuilder()
        .setColor('#E74C3C')
        .setTitle('<:nosound:1356948863922995312> Song Reupload Rejected!')
        .setDescription(`This song has been reuploaded already with:\n\nSong ID: \`${titleCheck.songID}\`\nSong Name: \`${titleCheck.songName}\``)
        .setFooter({ text: `This song already uploaded ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
      await sentMessage.edit({ embeds: [existsEmbed] });
      return 'exists';
    }

    await updateProgress(70, 'Uploading to server...');
    const headers = { 'User-Agent': 'Mozilla/5.1' };
    const response7 = await axios.get(
      `https://www.rickgdps.xyz/datastore/dashboard/api/addSong.php?download=${downloadUrl}&author=RickGDMusic&name=${filTit}`,
      { headers }
    );

    await updateProgress(90, 'Finalizing...');
    if (response7.data.dashboard && response7.data.success) {
      const songID = response7.data.song.ID;
      const songName = response7.data.song.name;
      try {
        await axios.get(`https://www.rickgdbot.xyz/admin/reupload.php?id=${songID}&title=${songName}&link=${link}`);
      } catch (err) {
        console.log('Failed to update database, but continuing');
      }
      await updateProgress(100, 'Completed!');
      
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`copy_song_id_${songID}`)
            .setLabel('Copy Song ID')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setLabel('Download Song')
            .setURL(finalDownloadUrl) 
            .setStyle(ButtonStyle.Link)
        );

      const successEmbed = new EmbedBuilder()
        .setColor('#2ECC71')
        .setTitle('RickGDBot Reupload Song')
        .setDescription(`<:successfully:1333466428174499860> **Successfully Reupload Song**\n\n<:song:1333468681627238470> **Song ID:** \`${songID}\`\n<:sound:1333470026614706239> **Song Name:** \`${songName}\`\n<:web:1333468807859273738> **URL:** ${link}\n\n<:query:1333468568213520494> Find songs easily in [RickGDBot Song and Sfx Library](https://www.rickgdbot.xyz/library/)`)
        .setFooter({ text: `Reuploaded song by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
      
      await sentMessage.edit({ 
        embeds: [successEmbed],
        components: [row]
      });

        const collector = sentMessage.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

        collector.on('collect', async i => {
            if (i.customId.startsWith('copy_song_id_')) {
                const idToCopy = i.customId.replace('copy_song_id_', '');
                await i.deferReply({ ephemeral: true });
                await i.editReply({ content: `\`${idToCopy}\`` });
            }
        });

        collector.on('end', collected => {
            const disabledRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`copy_song_id_${songID}`)
                        .setLabel('Copy Song ID')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setLabel('Download Song')
                        .setURL(finalDownloadUrl)
                        .setStyle(ButtonStyle.Link)
                        .setDisabled(true)
                );
            sentMessage.edit({ components: [disabledRow] }).catch(console.error);
        });

    } else {
      throw new Error('Failed to add the song to the database');
    }
  } catch (error) {
    const reason = error.response?.data?.error || error.message;
    const failedEmbed = new EmbedBuilder()
      .setColor('#E74C3C')
      .setTitle('RickGDBot Reuploading Throw an Error')
      .setDescription(`<:unsucess:1333466610156961962> I'm sorry your song reupload has been failed to reupload to the Rick GDPS Server\n\nReason: ${reason}`)
      .setThumbnail('https://files.catbox.moe/4l19p0.png')
      .setFooter({ text: `Contact the developer this error Harold Hutchin`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });
    await sentMessage.edit({ embeds: [failedEmbed] });
    throw error;
  }
}