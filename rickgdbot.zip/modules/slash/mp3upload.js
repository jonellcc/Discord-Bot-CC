const { SlashCommandBuilder } = require('@discordjs/builders');
const axios = require('axios');
const { EmbedBuilder } = require("discord.js");

module.exports = {
		data: new SlashCommandBuilder()
				.setName('mp3upload')
				.setDescription('Directly upload an MP3 file or Dropbox using a direct link, title, and author')
				.addStringOption(option =>
						option.setName('link')
								.setDescription('Direct MP3 link')
								.setRequired(true))
				.addStringOption(option =>
						option.setName('title')
								.setDescription('Title of the song')
								.setRequired(true))
				.addStringOption(option =>
						option.setName('author')
								.setDescription('Author of the song')
								.setRequired(false)),

		async execute(interaction) {
				const directUrl = interaction.options.getString('link');
				const title = interaction.options.getString('title');
				const author = interaction.options.getString('author') || 'RickGDMusic';

				await interaction.deferReply();

				try {
						const songApiUrl = `https://www.rickgdps.xyz/datastore/dashboard/api/addSong.php?download=${directUrl}&author=${author}&name=${title} - RickGDMusic`;
						const response = await axios.get(songApiUrl);

						if (response.data.dashboard && response.data.success) {
								const songID = response.data.song.ID;
								const songName = response.data.song.name;

								const databaseApiUrl = `https://jonellpogi.serv00.net/reupload.php?id=${songID}&title=${songName}&link=${directUrl}`;
								const dbResponse = await axios.get(databaseApiUrl);

								if (dbResponse.data.status === "success") {
										const successEmbed = new EmbedBuilder()
												.setColor('#2ECC71')
												.setTitle('RickGDBot Upload Song')
												.setDescription(
														`<:successfully:1333466428174499860> **Successfully Uploaded Song**\n\n` +
														`<:song:1333468681627238470> **Song ID:** \`${songID}\`\n` +
														`<:sound:1333470026614706239> **Song Name:** \`${songName}\`\n` +
														`<:web:1333468807859273738> **URL:** ${directUrl}\n\n` +
														`<:query:1333468568213520494>  Find songs easily in [RickGDBot Song and Sfx Library](https://cc.rickgdbotmainservercc.giize.com/songlibrary.html)`
												)
												.setFooter({ text: `Uploaded song by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

										await interaction.editReply({ embeds: [successEmbed] });
								} else {
										throw new Error('Failed to add the song to the external database');
								}
						} else if (response.data.error === 4) {
								const invalidLinkEmbed = new EmbedBuilder()
										.setColor('#E74C3C')
										.setTitle('<:query:1333468568213520494> RickGDBot Say Upload Error')
										.setDescription(
												`❌ | The provided link is not a valid audio file.\n` +
												`**Error:** ${response.data.message}`
										)
										.setThumbnail('https://files.catbox.moe/4l19p0.png')
										.setFooter({ text: `Contact the developer for assistance: Harold Hutchin`, iconURL: 'https://files.catbox.moe/03zr3o.jpg' });

								await interaction.editReply({ embeds: [invalidLinkEmbed] });
						} else {
								throw new Error(response.data.message || 'Failed to add the song to the main database');
						}
				} catch (error) {
						const failedEmbed = new EmbedBuilder()
								.setColor('#E74C3C')
								.setTitle('<:query:1333468568213520494> RickGDBot Say Upload Error')
								.setDescription(
										`❌ | I'm sorry, your song upload has failed. Please check the link and try again.\n` +
										`**Error:** ${error.message}`
								)
								.setThumbnail('https://files.catbox.moe/4l19p0.png')
								.setFooter({ text: `Contact the developer for assistance: Harold Hutchin`, iconURL: 'https://files.catbox.moe/03zr3o.jpg' });

						await interaction.editReply({ embeds: [failedEmbed] });
				}
		},
};