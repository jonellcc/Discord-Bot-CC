const { SlashCommandBuilder } = require('@discordjs/builders');
const axios = require('axios');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require("discord.js");
const fs = require('fs');

const tikTokRegex = /^(https?:\/\/)?(vt\.tiktok\.com|vm\.tiktok\.com|www\.tiktok\.com)/;
const capCutRegex = /^https:\/\/www\.capcut\.com\//;
const spotifyRegex = /^https:\/\/open\.spotify\.com\/track\//;
const soundCloudRegex = /^(https?:\/\/)?(m\.soundcloud\.com|soundcloud\.com|on\.soundcloud\.com)/;
const newgroundsRegex = /^(https?:\/\/)?(www\.newgrounds\.com\/audio\/listen\/\d+)/;
const googleDriveRegex = /^(https?:\/\/)?(drive\.google\.com\/file\/d\/[a-zA-Z0-9_-]+\/?)/;
const youtubeRegex = /^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=|embed\/|v\/|shorts\/)?([a-zA-Z0-9_-]{11})/;

let userCooldowns = {};
let dailyUsage = {};

try {
    userCooldowns = JSON.parse(fs.readFileSync('./modules/commands/cooldowns.json'));
} catch (err) {
    fs.writeFileSync('./modules/commands/cooldowns.json', JSON.stringify({}));
}

try {
    dailyUsage = JSON.parse(fs.readFileSync('./modules/commands/dailyUsage.json'));
} catch (err) {
    fs.writeFileSync('./modules/commands/dailyUsage.json', JSON.stringify({}));
}

function saveCooldowns() {
    fs.writeFileSync('./modules/commands/cooldowns.json', JSON.stringify(userCooldowns));
}

function saveDailyUsage() {
    fs.writeFileSync('./modules/commands/dailyUsage.json', JSON.stringify(dailyUsage));
}

function formatTime(ms) {
    if (ms > 3600000) return `${Math.floor(ms / 3600000)} hours`;
    if (ms > 60000) return `${Math.floor(ms / 60000)} minutes`;
    return `${Math.floor(ms / 1000)} seconds`;
}

async function checkExistingSong(link, title) {
    try {
        const response = await axios.get('https://www.rickgdbot.xyz/admin/reupload.php?all');
        const songs = response.data;
        
        const youtubeId = link.match(youtubeRegex)?.[1];
        
        for (const song of songs) {
            const existingYoutubeId = song.link.match(youtubeRegex)?.[1];
            
            if (youtubeId && existingYoutubeId && youtubeId === existingYoutubeId) {
                return { exists: true, songID: song.id, songName: song.title };
            }
            
            if (title && song.title.toLowerCase() === title.toLowerCase()) {
                return { exists: true, songID: song.id, songName: song.title };
            }
        }
        
        return { exists: false };
    } catch (error) {
        console.error('Error checking existing songs:', error);
        return { exists: false };
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('uploadsong')
        .setDescription('Reupload music or videos from URL or file')
        .addStringOption(option =>
            option.setName('url')
                .setDescription('Provide a URL link to music or video (e.g., YouTube, TikTok, SoundCloud)')
                .setRequired(false))
        .addAttachmentOption(option =>
            option.setName('file')
                .setDescription('Upload an audio or video file (Only music or video formats allowed)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('author')
                .setDescription('Optional author name for the song')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Optional title for the song')
                .setRequired(false)),

    async execute(interaction) {
        const userId = interaction.user.id;
        const currentTime = Date.now();
        const now = new Date();
        
        if (userCooldowns[userId] && currentTime < userCooldowns[userId].cooldownEnd) {
            const remainingTime = userCooldowns[userId].cooldownEnd - currentTime;
            const cooldownEmbed = new EmbedBuilder()
                .setColor('#E74C3C')
                .setTitle('<:timehshs:1364186671658172466> Command Cooldowns')
                .setDescription(`<@${userId}> **uploadsong** command has been cooldown\nPlease comeback at ${formatTime(remainingTime)} to reuse again thank you!`)
                .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });
            return interaction.reply({ embeds: [cooldownEmbed], ephemeral: true });
        }

        const today = now.toDateString();
        if (!dailyUsage[userId]) {
            dailyUsage[userId] = { date: today, count: 1 };
        } else {
            if (dailyUsage[userId].date !== today) {
                dailyUsage[userId] = { date: today, count: 1 };
            } else if (dailyUsage[userId].count >= 2) {
                const midnight = new Date();
                midnight.setHours(24, 0, 0, 0);
                const remainingTime = midnight - now;
                
                const limitEmbed = new EmbedBuilder()
                    .setColor('#E74C3C')
                    .setTitle('<:timehshs:1364186671658172466> Daily Limit Reached')
                    .setDescription(`<@${userId}> you have reached your daily limit of 5 uses for the **uploadsong** command. Please try again tomorrow.\n\nWaiting time: ${formatTime(remainingTime)}`)
                    .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });
                return interaction.reply({ embeds: [limitEmbed], ephemeral: true });
            } else {
                dailyUsage[userId].count += 1;
            }
        }

        const url = interaction.options.getString('url');
        const file = interaction.options.getAttachment('file');
        const author = interaction.options.getString('author') || 'RickGDMusic';
        const title = interaction.options.getString('title');

        if (!url && !file) {
            return interaction.reply({ content: "Please provide either a valid URL or an audio/video file.", ephemeral: true });
        }

        if (file) {
            const cdnLink = file.url;

            if (!['audio', 'video'].includes(file.contentType?.split('/')[0])) {
                return interaction.reply({ content: "Only audio and video files are allowed. Please upload a valid audio or video file.", ephemeral: true });
            }

            await processLink(cdnLink, interaction, true, author, title);
        } else if (url) {
            await processLink(url, interaction, false, author, title);
        }

        userCooldowns[userId] = { cooldownEnd: currentTime + 30000 };
        saveCooldowns();
        saveDailyUsage();
    },
};

async function processLink(link, interaction, isCdn, author, title) {
    const initialEmbed = new EmbedBuilder()
        .setColor('#3498DB')
        .setDescription('<:timehshs:1364186671658172466> Checking database...')
        .setThumbnail('https://files.catbox.moe/igl3bn.gif')
        .setFooter({ text: `Requesting reupload song by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

    const sentMessage = await interaction.reply({ embeds: [initialEmbed], fetchReply: true });

    async function updateProgress(percentage, status) {
        const progressEmbed = new EmbedBuilder()
            .setColor('#3498DB')
            .setDescription(`<a:dlgd:1368926386865180693> ${status}\nReuploading process at ${percentage}%`)
            .setFooter({ text: `Requesting reupload song by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

        await sentMessage.edit({ embeds: [progressEmbed] });
    }

    try {
        await updateProgress(10, 'Checking database...');

        const existingSong = await checkExistingSong(link, title);
        if (existingSong.exists) {
            const existsEmbed = new EmbedBuilder()
                .setColor('#E74C3C')
                .setTitle('<:nosound:1356948863922995312> Song Reupload Rejected!')
                .setDescription(`This song has been reuploaded already with:\n\nSong ID: \`${existingSong.songID}\`\nSong Name: \`${existingSong.songName}\``)
                .setFooter({ text: `This song already uploaded ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });
            return sentMessage.edit({ embeds: [existsEmbed] });
        }

        await updateProgress(20, 'Starting reupload process...');

        let apiUrl;
        let finalDownloadUrl = '';

        if (newgroundsRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/ng?url=${link}`;
        } else if (googleDriveRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/gd?url=${link}`;
        } else if (isCdn) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/cdn?url=${link}`;
        } else if (soundCloudRegex.test(link) && link.includes('on.soundcloud.com')) {
            const response = await axios.get(`https://jonellpogi.serv00.net/converturl.php?url=${encodeURIComponent(link)}`);
            await updateProgress(40, 'Converting SoundCloud link...');
            if (response.data && response.data.direct_link) {
                link = response.data.direct_link;
                apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/sc?url=${link}`;
            } else {
                throw new Error('Failed to convert SoundCloud link.');
            }
        } else if (tikTokRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/download?url=${link}`;
        } else if (capCutRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/cc?url=${link}`;
        } else if (spotifyRegex.test(link)) {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/spt?url=${link}`;
        } else {
            apiUrl = `https://cc.rickgdbotmainservercc.giize.com/api/jonell?url=${link}`;
        }

        await updateProgress(50, 'Downloading song...');

        const response1 = await axios.get(apiUrl);
        const downloadUrl = response1.data.finalUrl;
        const filTit = title || response1.data.filTit;
        finalDownloadUrl = response1.data.finalUrl;

        await updateProgress(70, 'Uploading to server...');

        let songApiUrl = `https://www.rickgdps.xyz/datastore/dashboard/api/addSong.php?download=${downloadUrl}&author=${encodeURIComponent(author)}&name=${encodeURIComponent(filTit)}`;

        const headers = { 'User-Agent': 'Mozilla/5.1' };
        const response7 = await axios.get(songApiUrl, { headers });

        await updateProgress(90, 'Finalizing...');

        if (response7.data.dashboard && response7.data.success) {
            const songID = response7.data.song.ID;
            const songName = response7.data.song.name;

            try {
                const dbResponse = await axios.get(`https://www.rickgdbot.xyz/admin/reupload.php?id=${songID}&title=${encodeURIComponent(songName)}&link=${encodeURIComponent(link)}`);
                
                if (dbResponse.data.status === "error" && dbResponse.data.message === "This song is already uploaded") {
                    const existsEmbed = new EmbedBuilder()
                        .setColor('#E74C3C')
                        .setTitle('<:nosound:1356948863922995312> Song Reupload Rejected!')
                        .setDescription(`This song has been reuploaded already with:\n\nSong ID: \`${songID}\`\nSong Name: \`${songName}\``)
                        .setFooter({ text: `This song Already Uploaded ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });
                    return sentMessage.edit({ embeds: [existsEmbed] });
                }
            } catch (dbError) {
                console.log('Database update error:', dbError);
            }

            await updateProgress(100, 'Completed!');

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`copy_song_id_${songID}`)
                        .setLabel('Copy Song ID')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setLabel('Download Song')
                        .setURL(finalDownloadUrl)
                        .setStyle(ButtonStyle.Link)
                );

            const successEmbed = new EmbedBuilder()
                .setColor('#2ECC71')
                .setTitle('RickGDBot Reupload Song')
                .setDescription(`<:successfully:1333466428174499860> **Successfully Reupload Song**\n\n<:song:1333468681627238470> **Song ID:** \`${songID}\`\n<:sound:1333470026614706239> **Song Name:** \`${songName}\`\n<:web:1333468807859273738> **URL:** ${link}\n\n<:query:1333468568213520494>  Find songs easily in [RickGDBot Song and Sfx Library](https://www.rickgdbot.xyz/library/)`)
                .setFooter({ text: `Reuploaded song by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

            await sentMessage.edit({ 
                embeds: [successEmbed],
                components: [row]
            });

            const collector = sentMessage.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

            collector.on('collect', async i => {
                if (i.customId.startsWith('copy_song_id_')) {
                    const idToCopy = i.customId.replace('copy_song_id_', '');
                    await i.deferReply({ ephemeral: true });
                    await i.editReply({ content: `Copied Song ID: \`${idToCopy}\`` });
                }
            });

            collector.on('end', collected => {
                const disabledRow = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`copy_song_id_${songID}`)
                            .setLabel('Copy Song ID')
                            .setStyle(ButtonStyle.Primary)
                            .setDisabled(true),
                        new ButtonBuilder()
                            .setLabel('Download Song')
                            .setURL(finalDownloadUrl)
                            .setStyle(ButtonStyle.Link)
                            .setDisabled(true)
                    );
                sentMessage.edit({ components: [disabledRow] }).catch(console.error);
            });

        } else {
            throw new Error('Failed to add the song to the database');
        }
    } catch (error) {
        console.error("Song upload error:", error);
        const reason = error.response?.data?.error || error.message;
        const failedEmbed = new EmbedBuilder()
            .setColor('#E74C3C')
            .setTitle('RickGDBot Reuploading Throw an Error')
            .setDescription(`<:unsucess:1333466610156961962> I'm sorry your song reupload has been failed to reupload to the Rick GDPS Server\n\nReason: ${reason}`)
            .setThumbnail('https://files.catbox.moe/4l19p0.png')
            .setFooter({ text: `Contact the developer for help`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });
        await sentMessage.edit({ embeds: [failedEmbed] });
    }
}