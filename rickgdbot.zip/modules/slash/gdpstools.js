const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('gdps_tools')
        .setDescription('Access various GDPS tools'),
    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('GDPS Tools')
            .setDescription('Here you can find all the tools that can help you in this GDPS!')
            .setColor('#00AAFF');

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('gdps_tools_menu')
            .setPlaceholder('Select your choice here!')
            .addOptions([
                { label: 'Search song', value: 'search_song', emoji: '🎵' },
                { label: 'Song reupload with .MP3 Link', value: 'song_reupload_link', emoji: '🎶' },
                { label: 'Song reupload with .MP3 File', value: 'song_reupload_file', emoji: '🎼' },
                { label: 'Know who rated level', value: 'know_who_rated', emoji: '⭐' }
            ]);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    },

    async selectMenuHandler(interaction) {
        if (!interaction.isStringSelectMenu()) return;
        
        const selectedValue = interaction.values[0];

        if (selectedValue === 'song_reupload_link') {
            const modal = new ModalBuilder()
                .setCustomId('song_reupload_modal')
                .setTitle('Song Reupload')
                .addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId('mp3_url')
                            .setLabel('Enter the .MP3 URL')
                            .setStyle(TextInputStyle.Short)
                            .setRequired(true)
                    )
                );

            await interaction.showModal(modal);
        }
    },

    async modalSubmitHandler(interaction) {
        if (!interaction.isModalSubmit()) return;

        if (interaction.customId === 'song_reupload_modal') {
            const mp3Url = interaction.fields.getTextInputValue('mp3_url');

            await interaction.reply({ content: `Executing command: \`/uploadsong ${mp3Url}\``, ephemeral: true });

            const command = interaction.client.commands.get('uploadsong');
            if (command) {
                await command.execute(interaction, { url: mp3Url });
            }
        }
    }
};