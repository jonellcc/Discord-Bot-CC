const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');
const fs = require('fs');

let userCooldowns = {};
let dailyUsage = {};

try {
    userCooldowns = JSON.parse(fs.readFileSync('./modules/commands/data/fxCooldowns.json'));
} catch (err) {
    fs.writeFileSync('./modules/commands/data/sfxCooldowns.json', JSON.stringify({}));
}

try {
    dailyUsage = JSON.parse(fs.readFileSync('./modules/commands/data/sfxDailyUsage.json'));
} catch (err) {
    fs.writeFileSync('./modules/commands/sfxDailyUsage.json', JSON.stringify({}));
}

function saveCooldowns() {
    fs.writeFileSync('./modules/commands/sfxCooldowns.json', JSON.stringify(userCooldowns));
}

function saveDailyUsage() {
    fs.writeFileSync('./modules/commands/sfxDailyUsage.json', JSON.stringify(dailyUsage));
}

function formatTime(ms) {
    if (ms > 3600000) return `${Math.floor(ms / 3600000)} hours`;
    if (ms > 60000) return `${Math.floor(ms / 60000)} minutes`;
    return `${Math.floor(ms / 1000)} seconds`;
}

async function checkExistingSFX(name, link) {
    try {
        const response = await axios.get('https://www.rickgdbot.xyz/admin/sfx.php?all');
        const sfxList = response.data;
        
        for (const sfx of sfxList) {
            if (name && sfx.name.toLowerCase() === name.toLowerCase()) {
                return { exists: true, sfx };
            }
            if (link && sfx.link === link) {
                return { exists: true, sfx };
            }
        }
        
        return { exists: false };
    } catch (error) {
        console.error('Error checking existing SFX:', error);
        return { exists: false };
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('uploadsfx')
        .setDescription('Upload an SFX (Sound Effect) via a URL.')
        .addStringOption(option =>
            option.setName('yturl')
                .setDescription('YouTube URL (Name is optional)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('urldirect')
                .setDescription('Direct MP3 URL (Name is required)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('name')
                .setDescription('Name of the SFX (Required for direct MP3)')
                .setRequired(false)),

    async execute(interaction) {
        const userId = interaction.user.id;
        const currentTime = Date.now();
        const now = new Date();
        
        if (userCooldowns[userId] && currentTime < userCooldowns[userId].cooldownEnd) {
            const remainingTime = userCooldowns[userId].cooldownEnd - currentTime;
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#E74C3C')
                        .setTitle('Command Cooldown')
                        .setDescription(`<:timehshs:1364186671658172466> <@${userId}> **uploadsfx** command has been cooldown\nPlease comeback at ${formatTime(remainingTime)} to reuse again thank you!`)
                        .setThumbnail('https://files.catbox.moe/zjvkxy.png')
                ],
                ephemeral: true
            });
        }

        const today = now.toDateString();
        if (!dailyUsage[userId]) {
            dailyUsage[userId] = { date: today, count: 1 };
        } else {
            if (dailyUsage[userId].date !== today) {
                dailyUsage[userId] = { date: today, count: 1 };
            } else if (dailyUsage[userId].count >= 5) {
                const midnight = new Date();
                midnight.setHours(24, 0, 0, 0);
                const remainingTime = midnight - now;
                
                return interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#E74C3C')
                            .setTitle('Daily Limit Reached')
                            .setDescription(`<:timehshs:1364186671658172466> <@${userId}> you have reached your daily limit of 5 uses for the **uploadsfx** command. Please try again tomorrow.\n\nWaiting time: ${formatTime(remainingTime)}`)
                            .setThumbnail('https://files.catbox.moe/zjvkxy.png')
                    ],
                    ephemeral: true
                });
            } else {
                dailyUsage[userId].count += 1;
            }
        }

        const yturl = interaction.options.getString('yturl');
        const urldirect = interaction.options.getString('urldirect');
        const name = interaction.options.getString('name');

        if (!yturl && !urldirect) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#E74C3C')
                        .setTitle('Error: Missing Arguments')
                        .setDescription('Please provide a valid URL (YouTube or direct MP3).\n\nUsage:\n- **YouTube URL** (Name is optional)\n- **Direct MP3 URL** (Name is required)\n\nExample:\n`/uploadsfx yturl:https://youtu.be/xyz`\n`/uploadsfx urldirect:https://example.com/sfx.mp3 name:SFX Name`\n\nVisit [Catbox Uploader](https://catbox.moe) to upload files.')
                        .setThumbnail('https://files.catbox.moe/zjvkxy.png')
                ],
                ephemeral: true
            });
        }

        if (urldirect && !name) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#E74C3C')
                        .setTitle('Error: Missing SFX Name')
                        .setDescription('A name is required when uploading a **direct MP3 file**.\n\nUsage:\n`/uploadsfx urldirect:https://example.com/sfx.mp3 name:SFX Name`')
                        .setThumbnail('https://files.catbox.moe/zjvkxy.png')
                ],
                ephemeral: true
            });
        }

        await interaction.deferReply();

        const username = interaction.user.username;
        const link = yturl || urldirect;

        async function updateProgress(percentage, status) {
            await interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#3498DB')
                        .setDescription(`<:timehshs:1364186671658172466> ${status}\nUploading process at **${percentage}%**`)
                        .setThumbnail('https://files.catbox.moe/igl3bn.gif')
                ]
            });
        }

        try {
            await updateProgress(10, 'Checking database...');

            const existingSFX = await checkExistingSFX(name, link);
            if (existingSFX.exists) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#E74C3C')
                            .setTitle('SFX Reupload Rejected')
                            .setDescription(`This SFX has been rejected to reupload because its already Reuploaded at name of SFX \`${existingSFX.sfx.name}\` at Folder SFX in \`${existingSFX.sfx.author}\``)
                            .setThumbnail('https://files.catbox.moe/5kt78l.png')
                    ]
                });
            }

            await updateProgress(20, 'Starting upload process...');

            let apiUrl;
            if (yturl) {
                apiUrl = name
                    ? `https://jonellpogi.serv00.net/sfxupload.php?yt=${encodeURIComponent(yturl)}&name=${encodeURIComponent(name)}`
                    : `https://jonellpogi.serv00.net/sfxupload.php?yt=${encodeURIComponent(yturl)}`;
            } else {
                apiUrl = `https://jonellpogi.serv00.net/sfx.php?url=${encodeURIComponent(urldirect)}&name=${encodeURIComponent(name)}`;
            }

            await updateProgress(40, 'Processing SFX...');
            const response = await axios.get(apiUrl);

            if (response.data.error === 'File size exceeds 1MB limit.') {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor('#E74C3C')
                            .setTitle('Error Uploading SFX')
                            .setDescription('<:unsucess:1333466610156961962> This YouTube link cannot be uploaded as an SFX because the **1MB limit** has been reached.')
                            .setThumbnail('https://files.catbox.moe/zjvkxy.png')
                    ]
                });
            }

            await updateProgress(60, 'Uploading to server...');
            const { message: apiMessage, data } = response.data;

            if (apiMessage === 'SFX added successfully.') {
                const databaseResponse = await axios.get(
                    `https://www.rickgdbot.xyz/admin/sfx.php?name=${encodeURIComponent(data.name)}&size=${encodeURIComponent(data.size)}&link=${encodeURIComponent(data.link)}&author=${encodeURIComponent(data.author)}&rt=${encodeURIComponent(data.reupload_time)}`
                );

                if (databaseResponse.data.status === "error" && databaseResponse.data.message === "This name or link is already uploaded in the database") {
                    return interaction.editReply({
                        embeds: [
                            new EmbedBuilder()
                                .setColor('#E74C3C')
                                .setTitle('SFX Reupload Rejected')
                                .setDescription(`This SFX has been rejected to reupload because its already Reuploaded at name of SFX \`${data.name}\``)
                                .setThumbnail('https://files.catbox.moe/5kt78l.png')
                        ]
                    });
                }

                if (databaseResponse.data.status === "success" && databaseResponse.data.message === "Successfully Added list") {
                    await updateProgress(100, 'Completed!');

                    return interaction.editReply({
                        embeds: [
                            new EmbedBuilder()
                                .setColor('#2ECC71')
                                .setTitle('<:successfully:1333466428174499860> SFX Uploaded Successfully')
                                .setDescription(`👤 Uploaded by **${username}**\n\n<:sfx:1333483217264840808> SFX Name: **${data.name}**\n<:profile:1333486106578260082> SFX Author: **${data.author}**\n<:folder:1333485662149545994> Size: **${data.size}**`)
                                .addFields(
                                    { name: '<:dl:1333482602320892045> Download Link', value: `[Click Here](${data.link})`, inline: false },
                                    { name: '<:time:1333483136100864032> Reupload Time', value: data.reupload_time, inline: true },
                                    { name: '<:web:1333468807859273738> SFX Library', value: '[RickGDBot Library SFX](https://www.rickgdbot.xyz/library/)', inline: false }
                                )
                        ]
                    });
                } else {
                    throw new Error('Failed to add SFX to the database');
                }
            } else {
                throw new Error('Failed to add SFX');
            }
        } catch (error) {
            console.error("SFX upload error:", error);
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#E74C3C')
                        .setTitle('Reupload SFX Error')
                        .setDescription(`<:unsucess:1333466610156961962> | Reupload failed. Try another link or check the RGDPS server.`)

                ]
            });
        } finally {
            userCooldowns[userId] = { cooldownEnd: currentTime + 10000 };
            saveCooldowns();
            saveDailyUsage();
        }
    },
};