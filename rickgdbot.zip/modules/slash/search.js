const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const axios = require('axios');
const stringSimilarity = require('string-similarity');

module.exports = {
		data: new SlashCommandBuilder()
				.setName('search')
				.setDescription('Search for a song or SFX in the uploaded list or show the latest 10 items if no query is provided.')
				.addStringOption(option =>
						option.setName('type')
								.setDescription('Choose whether to search for a song or SFX')
								.setRequired(true)
								.addChoices(
										{ name: 'Song', value: 'song' },
										{ name: 'SFX', value: 'sfx' }
								))
				.addStringOption(option =>
						option.setName('query')
								.setDescription('Enter the name or ID of the song or SFX to search')
								.setRequired(false)
				),

		async execute(interaction) {
				const type = interaction.options.getString('type');
				const query = interaction.options.getString('query')?.toLowerCase();

				try {
						let apiUrl = type === 'song'
								? 'https://www.rickgdbot.xyz/admin/reupload.php?all'
								: 'https://www.rickgdbot.xyz/admin/sfx.php?all';

						const response = await axios.get(apiUrl);
						const items = response.data;

						if (!Array.isArray(items)) throw new Error('Invalid API response: Expected an array.');

						let results = [];

						if (!query) {
								results = items.slice(0, 10);
						} else {
								results = items.filter(item =>
										(type === 'sfx' ? item.name : item.title).toLowerCase().includes(query) || item.id.toString() === query
								);
						}

						if (results.length === 0) {
								const titles = items.map(item => (type === 'sfx' ? item.name : item.title).toLowerCase());
								const matches = stringSimilarity.findBestMatch(query, titles);

								if (matches.bestMatch.rating >= 0.5) {
										const bestMatch = items[matches.bestMatchIndex];

										const matchEmbed = new EmbedBuilder()
												.setColor('#F1C40F')
												.setTitle('No Exact Match Found — Showing Closest Match')
												.setDescription(
														`**${type === 'sfx' ? 'Name' : 'Title'}:** ${bestMatch[type === 'sfx' ? 'name' : 'title']}\n` +
														`**Link:** [Click here](${bestMatch.link})\n` +
														`**Uploaded:** ${bestMatch.reupload_time}\n\n` +
														`Closest match based on your search: **"${matches.bestMatch.target}"**`
												);

										return interaction.reply({ embeds: [matchEmbed] });
								} else {
										const noResultsEmbed = new EmbedBuilder()
												.setColor('#E74C3C')
												.setTitle('No Results Found')
												.setDescription(`No ${type === 'sfx' ? 'SFX' : 'songs'} found matching **"${query}"**.`);
										return interaction.reply({ embeds: [noResultsEmbed] });
								}
						}

						let page = 0;
						const pageSize = 10;

						const getPage = (page) => {
								const start = page * pageSize;
								const end = start + pageSize;
								return results.slice(start, end);
						};

						const generateEmbed = (page) => {
								const paginatedResults = getPage(page);

								const embed = new EmbedBuilder()
										.setColor(type === 'sfx' ? '#F39C12' : '#3498DB')
										.setTitle(query ? `Search Results for "${query}"` : `Latest Uploaded ${type === 'sfx' ? 'SFX' : 'Songs'}`)
										.setDescription(paginatedResults.map(item => {
												let description = `**${type === 'sfx' ? 'Name' : 'Title'}:** ${item[type === 'sfx' ? 'name' : 'title']}\n` +
																					`**Link:** [Click here](${item.link})\n`;

												if (type === 'song') {
														const youtubeLink = item.link.includes("youtube") ? item.link : 'No YouTube link available';
														description += `**Song ID:** ${item.id}\n**YouTube Link:** ${youtubeLink}`;
												} else {
														description += `**Size:** ${item.size}`;
												}

												return description;
										}).join('\n\n'))
										.setFooter({ text: `Page ${page + 1} of ${Math.ceil(results.length / pageSize)}` });

								return embed;
						};

						const row = new ActionRowBuilder().addComponents(
								new ButtonBuilder()
										.setCustomId('prev')
										.setLabel('⬅️ Previous')
										.setStyle(ButtonStyle.Primary)
										.setDisabled(page === 0),
								new ButtonBuilder()
										.setCustomId('next')
										.setLabel('Next ➡️')
										.setStyle(ButtonStyle.Primary)
										.setDisabled(results.length <= pageSize)
						);

						const sentMessage = await interaction.reply({ embeds: [generateEmbed(page)], components: [row] });

						const collector = sentMessage.createMessageComponentCollector({ time: 60000 });

						collector.on('collect', async (interaction) => {
								if (interaction.user.id !== interaction.user.id) {
										return interaction.reply({ content: 'You can’t control this navigation!', ephemeral: true });
								}

								if (interaction.customId === 'prev' && page > 0) page--;
								if (interaction.customId === 'next' && (page + 1) * pageSize < results.length) page++;

								await interaction.update({ embeds: [generateEmbed(page)], components: [row] });

								row.components[0].setDisabled(page === 0);
								row.components[1].setDisabled((page + 1) * pageSize >= results.length);
						});

						collector.on('end', () => {
								sentMessage.edit({ components: [] });
						});

				} catch (error) {
						console.error("Error fetching or processing data:", error);

						const errorEmbed = new EmbedBuilder()
								.setColor('#E74C3C')
								.setTitle('Error: Unable to Fetch Data')
								.setDescription('There was an error retrieving the list. Please try again later.');
						return interaction.reply({ embeds: [errorEmbed] });
				}
		}
};