const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
		config: {
				name: 'autorepup',
				description: 'Automatically detects links and asks if the user wants to reupload the song',
		},

		events: ({ discord }) => {
				const client = discord.client;

				const tikTokRegex = /^(https?:\/\/)?(vt\.tiktok\.com|vm\.tiktok\.com|www\.tiktok\.com)/;
				const capCutRegex = /^https:\/\/www\.capcut\.com\//;
				const spotifyRegex = /^https:\/\/open\.spotify\.com\/track\//;
				const soundCloudRegex = /^(https?:\/\/)?(m\.soundcloud\.com|soundcloud\.com|on\.soundcloud\.com)/;
				const newgroundsRegex = /^(https?:\/\/)?(www\.newgrounds\.com\/audio\/listen\/\d+)/;
				const googleDriveRegex = /^(https?:\/\/)?(drive\.google\.com\/file\/d\/[a-zA-Z0-9_-]+\/?)/;
				const dropboxRegex = /^https:\/\/www\.dropbox\.com\/scl\/fi\/[a-zA-Z0-9_-]+\/.+\?rlkey=[a-zA-Z0-9]+&dl=0$/;
				const youtubeRegex = /^(https?:\/\/)?(www\.youtube\.com\/watch\?v=[a-zA-Z0-9_-]+|youtu\.be\/[a-zA-Z0-9_-]+|music\.youtube\.com\/watch\?v=[a-zA-Z0-9_-]+|you\.tube\/[a-zA-Z0-9_-]+)/;

				client.on('messageCreate', async (message) => {
						if (message.author.bot || !message.guild) return;

						const content = message.content.trim();

						let linkDetected = null;
						if (tikTokRegex.test(content)) {
								linkDetected = 'TikTok';
						} else if (capCutRegex.test(content)) {
								linkDetected = 'CapCut';
						} else if (spotifyRegex.test(content)) {
								linkDetected = 'Spotify';
						} else if (soundCloudRegex.test(content)) {
								linkDetected = 'SoundCloud';
						} else if (newgroundsRegex.test(content)) {
								linkDetected = 'Newgrounds';
						} else if (googleDriveRegex.test(content)) {
								linkDetected = 'Google Drive';
						} else if (dropboxRegex.test(content)) {
								linkDetected = 'Dropbox';
						} else if (youtubeRegex.test(content)) {
								linkDetected = 'YouTube';
						}

						if (linkDetected) {
								const linkMatch = content.match(/https?:\/\/\S+/)[0];

								const embed = new EmbedBuilder()
										.setColor('#0099FF')
										.setTitle('Link Detected')
										.setDescription(`Hey ${message.author}, I see the following link is reuploadable in Rick GDPS: ${linkMatch}. Do you want to reupload this song? You have 15 seconds to confirm!`)
										.setFooter({ text: 'You have 15 seconds to confirm!' });

								const row = new ActionRowBuilder().addComponents(
										new ButtonBuilder()
												.setCustomId('reupload')
												.setLabel('Reupload')
												.setStyle(ButtonStyle.Success),
										new ButtonBuilder()
												.setCustomId('reject')
												.setLabel('Reject')
												.setStyle(ButtonStyle.Danger)
								);

								const sentMessage = await message.reply({ embeds: [embed], components: [row] });

								let timeLeft = 15;
								const countdownInterval = setInterval(() => {
										if (timeLeft === 0) {
												clearInterval(countdownInterval);
										} else {
												timeLeft--;
										}
										embed.setDescription(`Hey ${message.author}, I see the following link is reuploadable in Rick GDPS: ${linkMatch}. Do you want to reupload this song? You have ${timeLeft} seconds to confirm!`);
										sentMessage.edit({ embeds: [embed] });
								}, 1000);

								const filter = (interaction) => interaction.user.id === message.author.id;
								const collector = sentMessage.createMessageComponentCollector({
										filter,
										time: 15000,
								});

								collector.on('collect', async (interaction) => {
										if (interaction.customId === 'reupload') {
												clearInterval(countdownInterval);
												await interaction.update({ content: 'Reuploading song...', components: [] });
												client.commands.get('uploadsong').letStart({ args: [linkMatch], message, discord: { client } });
												sentMessage.delete();
										} else if (interaction.customId === 'reject') {
												clearInterval(countdownInterval);
												await interaction.update({ content: 'Rejected Reupload Song.', components: [] });
												sentMessage.delete();
										}
								});

								collector.on('end', (collected, reason) => {
										if (reason === 'time') {
												sentMessage.edit({ content: 'You took too long to respond. Reupload rejected.', components: [] });
										}
								});
						}
				});
		},
};